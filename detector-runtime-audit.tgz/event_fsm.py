# Architecture: Hexagonal
# Domain layer: no imports from adapters

from enum import Enum
from dataclasses import dataclass
from typing import Optional


class State(Enum):
    IDLE       = "idle"       # Esperando primer beige (calibración)
    BEIGE_IN   = "beige_in"   # Separador beige visible, esperando prenda
    EN_PRENDA  = "en_prenda"  # Prenda pasando, esperando siguiente beige
    COOLDOWN   = "cooldown"   # Pausa breve post-CORTE


@dataclass
class FSMConfig:
    # Calibración en IDLE
    calibration_frames:  int   = 20    # frames de beige sostenido para calibrar
    # Detección de beige con HISTÉRESIS (2 umbrales)
    beige_high:          float = 0.55  # beige_ratio >= este valor → SÍ es separador beige
    beige_low:           float = 0.30  # beige_ratio <  este valor → es prenda (sin beige)
                                       # zona 0.30-0.55 = ambigua, no cuenta (filtra falsos positivos)
    beige_confirm_frames: int  = 10    # frames consecutivos de beige_high para confirmar separador
    beige_exit_frames:   int  = 8     # frames consecutivos de beige_low para confirmar prenda iniciada
    # Post-CORTE
    cooldown_frames:     int   = 6
    min_rearm_s:         float = 2.0   # mínimo segundos entre CORTEs


class EventFSM:
    def __init__(self, config: FSMConfig):
        import time as _time
        self.config = config
        self._state             = State.IDLE
        self._beige_streak      = 0   # frames consecutivos con beige (>= beige_high)
        self._no_beige_streak   = 0   # frames consecutivos sin beige (< beige_low)
        self._calibration_count = 0   # frames acumulados en calibración IDLE
        self._cooldown_counter  = 0
        self._last_corte_time   = -999.0
        self._time              = _time

    def process(self, fusion_score: float, beige_ratio: float) -> Optional[str]:
        """
        Retorna: None | 'CALIBRATE' | 'CORTE'

        Lógica de conteo con histéresis:
          Panel: [BEIGE][PRENDA1][BEIGE][PRENDA2][BEIGE]...[PRENDAN][BEIGE]
          Total prendas = total separadores beige - 1

          - beige_ratio >= beige_high (0.55) → SÍ hay separador beige
          - beige_ratio <  beige_low  (0.30) → es prenda (no hay beige)
          - zona intermedia (0.30-0.55)      → ambiguo, mantiene estado (no cuenta)

          Cada vez que reaparece beige sólido después de una prenda → CORTE.
        """
        if self._state == State.IDLE:
            return self._handle_idle(beige_ratio)
        if self._state == State.BEIGE_IN:
            return self._handle_beige_in(beige_ratio)
        if self._state == State.EN_PRENDA:
            return self._handle_en_prenda(beige_ratio)
        if self._state == State.COOLDOWN:
            return self._handle_cooldown()
        return None

    def _handle_idle(self, beige_ratio: float) -> Optional[str]:
        """Acumula frames de beige sólido para calibración dinámica."""
        if beige_ratio >= self.config.beige_high:
            self._calibration_count += 1
            if self._calibration_count >= self.config.calibration_frames:
                # Beige calibrado — transicionar a BEIGE_IN y pedir calibración al servicio
                self._state = State.BEIGE_IN
                self._beige_streak = 0
                self._no_beige_streak = 0
                self._calibration_count = 0
                return 'CALIBRATE'
        else:
            self._calibration_count = 0
        return None

    def _handle_beige_in(self, beige_ratio: float) -> Optional[str]:
        """Beige visible. Espera que desaparezca (beige < beige_low) para confirmar prenda."""
        if beige_ratio < self.config.beige_low:
            self._no_beige_streak += 1
            self._beige_streak = 0
            if self._no_beige_streak >= self.config.beige_exit_frames:
                # La prenda empezó a pasar (beige desapareció de forma sostenida)
                self._state = State.EN_PRENDA
                self._no_beige_streak = 0
        else:
            # beige >= beige_low → sigue habiendo beige (o zona ambigua) → resetea salida
            self._no_beige_streak = 0
        return None

    def _handle_en_prenda(self, beige_ratio: float) -> Optional[str]:
        """Prenda pasando. Espera beige SÓLIDO (>= beige_high) para confirmar separador → CORTE."""
        if beige_ratio >= self.config.beige_high:
            self._beige_streak += 1
            self._no_beige_streak = 0
            if self._beige_streak >= self.config.beige_confirm_frames:
                # Siguiente separador beige confirmado → 1 prenda completada
                now = self._time.time()
                if (now - self._last_corte_time) < self.config.min_rearm_s:
                    # Demasiado rápido — volver a BEIGE_IN sin emitir
                    self._state = State.BEIGE_IN
                    self._beige_streak = 0
                    return None
                self._last_corte_time = now
                self._state = State.COOLDOWN
                self._cooldown_counter = 0
                self._beige_streak = 0
                return 'CORTE'
        else:
            # beige < beige_high → no es separador sólido (incluye zona ambigua) → resetea
            self._beige_streak = 0
        return None

    def _handle_cooldown(self) -> Optional[str]:
        self._cooldown_counter += 1
        if self._cooldown_counter >= self.config.cooldown_frames:
            # Volver a BEIGE_IN porque el separador sigue visible post-CORTE
            self._state = State.BEIGE_IN
            self._cooldown_counter = 0
            self._beige_streak = 0
            self._no_beige_streak = 0
        return None

    def reset(self) -> None:
        self._state             = State.IDLE
        self._beige_streak      = 0
        self._no_beige_streak   = 0
        self._calibration_count = 0
        self._cooldown_counter  = 0
        self._last_corte_time   = -999.0

    @property
    def state(self) -> State:
        return self._state
